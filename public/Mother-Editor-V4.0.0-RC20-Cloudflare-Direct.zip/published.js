/* MOTHER EDITOR V4 Published Runtime — one countdown manager */
(() => {
  'use strict';
  let timer = null;
  const update = () => {
    document.querySelectorAll('[data-countdown-end]').forEach(node => {
      const end = new Date(node.dataset.countdownEnd).getTime();
      let left = Math.max(0, end - Date.now());
      const values = {days:Math.floor(left/86400000),hours:Math.floor(left/3600000)%24,minutes:Math.floor(left/60000)%60,seconds:Math.floor(left/1000)%60};
      Object.entries(values).forEach(([key,value]) => { const el=node.querySelector(`[data-unit="${key}"]`); if(el) el.textContent=String(value).padStart(2,'0'); });
    });
  };
  update();

  const share = document.getElementById('publishedShare');
  const panel = document.getElementById('publishedSharePanel');
  const native = document.getElementById('nativeShare');
  const wa = document.getElementById('waShare');
  const fb = document.getElementById('fbShare');
  const close = document.getElementById('closePublishedShare');
  if (share && panel) {
    const title = document.querySelector('meta[property="og:title"]')?.content || document.title || 'Mother Editor Landing Page';
    const description = document.querySelector('meta[property="og:description"]')?.content || document.querySelector('meta[name="description"]')?.content || '';
    const pageUrl = location.href;
    share.addEventListener('click', () => panel.classList.toggle('open'));
    close?.addEventListener('click', () => panel.classList.remove('open'));
    native?.addEventListener('click', async () => {
      try {
        if (navigator.share) await navigator.share({title, text: description, url: pageUrl});
        else if (navigator.clipboard) { await navigator.clipboard.writeText(pageUrl); }
      } catch (_) {}
    });
    wa?.addEventListener('click', () => { location.href = 'https://wa.me/?text=' + encodeURIComponent(title + '\n' + pageUrl); });
    fb?.addEventListener('click', () => { window.open('https://www.facebook.com/sharer/sharer.php?u=' + encodeURIComponent(pageUrl), '_blank', 'noopener,noreferrer'); });
  }
  document.querySelectorAll('form').forEach(form => form.addEventListener('submit', e => e.preventDefault()));
  if (document.querySelector('[data-countdown-end]')) timer=setInterval(update,1000);
  window.addEventListener('pagehide',()=>{if(timer)clearInterval(timer);});
})();
