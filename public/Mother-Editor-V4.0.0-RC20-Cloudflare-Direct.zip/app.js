/* MOTHER EDITOR V4.0.0 RC3 — Clean Architecture
   State → Schema → Registry → Smart Target → Editors → Renderer → Publish
*/
(() => {
  'use strict';
  const VERSION = '4.0.0-rc18';
  const STORAGE = 'mother-editor-v4-draft';
  const MAX_HISTORY = 50;

  const TOOLS = [
    ['ai','M-AI','🧠'],['text','টেক্সট','T'],['image','ইমেজ','▧'],['button','বাটন','▣'],['icon','আইকন','✦'],['shape','শেপ','◆'],
    ['video','ভিডিও','▶'],['input','ইনপুট','⌨'],['line','লাইন','—'],['section','সেকশন','▤'],['column','কলাম','▥'],
    ['offer','অফার','%'],['countdown','কাউন্টডাউন','◷'],['payment','পেমেন্ট','৳'],['faq','FAQ','?'],
    ['json-in','ইনপুট JSON','{}'],['json-out','আউটপুট JSON','↗'],['html','HTML এলিমেন্ট','</>'],['preview','প্রিভিউ','◉'],
    ['settings','সেটিংস','⚙'],['seo','SEO','⌕'],['analytics','অ্যানালিটিক্স','▥'],['template','টেমপ্লেট','▦']
  ];

  const uid = (type='el') => `${type}_${crypto.getRandomValues(new Uint32Array(2)).join('').slice(0,10)}`;
  const clone = o => JSON.parse(JSON.stringify(o));
  const esc = s => String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const safeUrl = value => {
    const s = String(value ?? '#').trim();
    if (/^(javascript|data|vbscript):/i.test(s)) return '#';
    if (/^data:image\/(png|jpe?g|webp|gif);base64,/i.test(s)) return s;
    if (/^https?:\/\//i.test(s) || /^mailto:/i.test(s) || /^tel:/i.test(s) || /^#/i.test(s) || /^\//.test(s)) return s;
    return '#';
  };
  const iso = value => { const d = new Date(value); return Number.isFinite(d.getTime()) ? d.toISOString() : null; };

  const state = {
    schemaVersion: 1,
    version: VERSION,
    page: { id:'page_001', slug:'my-page', language:'bn', title:'Mother Editor V4 Sales Page' },
    settings: {
      seo: { title:'Mother Editor — Digital Product Sales Page', description:'A clean editable sales page.', canonical:'', robots:'index,follow', ogTitle:'', ogDescription:'', ogImage:'' },
      theme: { primary:'#FF0F57', hover:'#E9004F', canvas:'#F4F6FF', card:'#FFFFFF' }
    },
    sections: [
      {id:'hero_001',type:'section',role:'hero',children:['text_hero','image_hero','button_hero'],props:{title:'আপনার কাজকে করুন',highlight:'আরও সহজ ও প্রফেশনাল',lead:'আপনার প্রয়োজনীয় সবকিছু এক জায়গায় — সহজ, দ্রুত এবং ব্যবহারযোগ্য ডিজিটাল সমাধান।'}},
      {id:'trust_001',type:'section',role:'trust',children:['trust_001_el'],props:{items:['Mobile Responsive','Easy to Customize','Sales Ready']}},
      {id:'why_001',type:'section',role:'why',children:['why_001_el'],props:{title:'কেন এটি ব্যবহার করবেন?',items:['Professional sales-ready design','Mobile + desktop responsive','Easy editing without coding','Fast publish with live link']}},
      {id:'rating_001',type:'section',role:'rating',children:['rating_001_el'],props:{score:'4.9',count:'250+',label:'Customer Rating'}},
      {id:'offer_001',type:'section',role:'offer',children:['offer_001_el'],props:{title:'বিশেষ অফার',price:'499',oldPrice:'999',label:'Limited Time Offer'}},
      {id:'countdown_001',type:'section',role:'countdown',children:['countdown_001_el'],props:{endAt:new Date(Date.now()+48*60*60*1000).toISOString()}},
      {id:'order_001',type:'section',role:'order',children:['order_001_el'],props:{title:'এখনই অর্ডার করুন'}},
      {id:'payment_001',type:'section',role:'payment',children:['payment_001_el'],props:{bkash:'01XXXXXXXXX',nagad:'01XXXXXXXXX',reference:'YOUR_REFERENCE'}},
      {id:'faq_001',type:'section',role:'faq',children:['faq_001_el'],props:{items:[['আমি কী পাব?','একটি সম্পূর্ণ editable digital product sales page template পাবেন।'],['Payment করার পর কীভাবে পাব?','আপনার delivery process অনুযায়ী file বা access link দেওয়া হবে।'],['নিজের দাম কি দিতে পারব?','হ্যাঁ, Offer editor থেকে নিজের দাম বসাতে পারবেন।']]}}
    ],
    elements: {
      text_hero:{id:'text_hero',type:'text',sectionId:'hero_001',role:'hero_text',props:{text:'আপনার ডিজিটাল পণ্যের জন্য একটি Professional Sales Page'}},
      image_hero:{id:'image_hero',type:'image',sectionId:'hero_001',role:'hero_image',props:{src:'',alt:'Product preview'}},
      button_hero:{id:'button_hero',type:'button',sectionId:'hero_001',role:'primary_cta',props:{text:'এখনই কিনুন',action:'scroll',url:'#order',target:'self'},style:{background:'#FF0F57',hoverBackground:'#E9004F',color:'#FFFFFF'}},
      trust_001_el:{id:'trust_001_el',type:'trust',sectionId:'trust_001',role:'trust_row',props:{}},
      why_001_el:{id:'why_001_el',type:'why',sectionId:'why_001',role:'why_block',props:{}},
      rating_001_el:{id:'rating_001_el',type:'rating',sectionId:'rating_001',role:'rating_block',props:{}},
      offer_001_el:{id:'offer_001_el',type:'offer',sectionId:'offer_001',role:'offer_block',props:{}},
      countdown_001_el:{id:'countdown_001_el',type:'countdown',sectionId:'countdown_001',role:'offer_countdown',props:{}},
      order_001_el:{id:'order_001_el',type:'order',sectionId:'order_001',role:'order_form',props:{}},
      payment_001_el:{id:'payment_001_el',type:'payment',sectionId:'payment_001',role:'payment_block',props:{}},
      faq_001_el:{id:'faq_001_el',type:'faq',sectionId:'faq_001',role:'faq_block',props:{}}
    }
  };

  const history = [], future = [];
  let selectedId = null, editorMode = true, dirty = false, timer = null;

  const registry = {
    get(id){ return state.elements[id] || null; },
    all(){ return Object.values(state.elements); },
    find(query={}){ return this.all().filter(el => Object.entries(query).every(([k,v]) => el[k] === v || el.props?.[k] === v)); },
    byType(type){ return this.all().filter(el => el.type === type); },
    section(role){ return state.sections.find(s => s.role === role) || null; },
    children(sectionId){ const s = state.sections.find(x => x.id === sectionId); return (s?.children || []).map(id => this.get(id)).filter(Boolean); },
    validate(){
      const ids = new Set(); const errors = [];
      for (const s of state.sections) {
        if (ids.has(s.id)) errors.push(`Duplicate section ID: ${s.id}`); ids.add(s.id);
        for (const id of s.children || []) if (!state.elements[id]) errors.push(`Missing element: ${id}`);
      }
      for (const e of this.all()) {
        if (ids.has(e.id)) errors.push(`Duplicate element ID: ${e.id}`); ids.add(e.id);
        if (!e.type || !e.sectionId) errors.push(`Invalid element: ${e.id}`);
      }
      return errors;
    }
  };

  function validateState(candidate=state){
    if (!candidate || candidate.schemaVersion !== 1 || !candidate.page || !Array.isArray(candidate.sections) || !candidate.elements) return ['Invalid V4 state schema'];
    const errors=[]; const ids=new Set();
    for(const s of candidate.sections){
      if(!s.id || s.type!=='section' || !s.role || !Array.isArray(s.children)) errors.push(`Invalid section: ${s.id||'unknown'}`);
      if(ids.has(s.id)) errors.push(`Duplicate ID: ${s.id}`); ids.add(s.id);
      for(const id of s.children) if(!candidate.elements[id]) errors.push(`Missing element: ${id}`);
    }
    for(const e of Object.values(candidate.elements)){
      if(!e.id||!e.type||!e.sectionId) errors.push(`Invalid element: ${e.id||'unknown'}`);
      if(ids.has(e.id)) errors.push(`Duplicate ID: ${e.id}`); ids.add(e.id);
      if(!candidate.sections.some(s=>s.id===e.sectionId)) errors.push(`Orphan element: ${e.id}`);
    }
    return errors;
  }

  function snapshot(){ history.push(clone(state)); if(history.length>MAX_HISTORY) history.shift(); future.length=0; dirty=true; updateSave(); }
  function restore(next){ const errors=validateState(next); if(errors.length){ toast(errors[0]); return; } Object.keys(state).forEach(k=>delete state[k]); Object.assign(state,clone(next)); selectedId=null; render(); refreshInspector(); updateSave(); }
  function undo(){ if(!history.length)return; future.push(clone(state)); restore(history.pop()); toast('Undo'); }
  function redo(){ if(!future.length)return; history.push(clone(state)); restore(future.pop()); toast('Redo'); }

  function targetCandidates(tool){
    const maps={text:{type:'text'},image:{type:'image'},button:{type:'button'},video:{type:'video'},rating:{type:'rating'},offer:{type:'offer'},countdown:{type:'countdown'},payment:{type:'payment'},faq:{type:'faq'}};
    return maps[tool] ? registry.byType(maps[tool].type) : [];
  }
  function smartTarget(tool, direction=0){
    const list=targetCandidates(tool); if(!list.length){ toast('Target not found — নতুন section তৈরি করা হয়নি'); return null; }
    const current = selectedId ? list.findIndex(x=>x.id===selectedId) : -1;
    const index = direction ? (current<0 ? 0 : (current+direction+list.length)%list.length) : (current<0 ? 0 : current);
    return list[index];
  }
  function targetAndEdit(tool, direction=0){ const target=smartTarget(tool,direction); if(!target)return; selectElement(target.id); openEditor(target); }

  function selectElement(id){
    selectedId=id;
    document.querySelectorAll('[data-element-id]').forEach(n=>n.classList.toggle('selected',n.dataset.elementId===id));
    refreshInspector();
  }

  function openEditor(el){
    const box=document.getElementById('inspector'); if(!box||!el)return;
    const nav=targetCandidates(el.type).length>1 ? `<div class="target-nav"><button data-action="target-prev" data-tool="${esc(el.type)}">← Previous</button><span>${targetCandidates(el.type).findIndex(x=>x.id===el.id)+1} / ${targetCandidates(el.type).length}</span><button data-action="target-next" data-tool="${esc(el.type)}">Next →</button></div>` : '';
    let h=`<div class="ins-head"><b>${esc(el.type.toUpperCase())} EDITOR</b><button data-action="close-inspector">×</button></div><div class="ins-id">ID: ${esc(el.id)}</div>${nav}`;
    if(el.type==='button') h+=`<label>Button Text</label><input id="edText" value="${esc(el.props.text)}"><label>Font Size (px)</label><div class="button-font-row"><button type="button" data-font-step="-1">−</button><input id="edFontSize" type="number" min="10" max="72" value="${Number(el.style?.fontSize||16)}"><button type="button" data-font-step="1">+</button></div><label>Action</label><select id="edAction"><option value="scroll" ${el.props.action==='scroll'?'selected':''}>Scroll</option><option value="url" ${el.props.action==='url'?'selected':''}>URL</option></select><label>Target / URL</label><input id="edUrl" value="${esc(el.props.url)}"><label>Target</label><select id="edTarget"><option value="self" ${el.props.target!=='blank'?'selected':''}>Same tab</option><option value="blank" ${el.props.target==='blank'?'selected':''}>New tab</option></select><label>Button Color</label><input id="edBg" type="color" value="${esc(el.style?.background||'#FF0F57')}"><label>Hover Color</label><input id="edHoverBg" type="color" value="${esc(el.style?.hoverBackground||'#E9004F')}"><label>Text Color</label><input id="edColor" type="color" value="${esc(el.style?.color||'#FFFFFF')}"><button class="apply" data-action="apply-button">Save Button</button>`;
    else if(el.type==='text') h+=`<label>Text</label><textarea id="edText">${esc(el.props.text)}</textarea><button class="apply" data-action="apply-text">Save Text</button>`;
    else if(el.type==='image') h+=`<label>Image URL</label><input id="edUrl" value="${esc(el.props.src)}"><label>Alt Text</label><input id="edAlt" value="${esc(el.props.alt)}"><button class="apply" data-action="apply-image">Save Image</button>`;
    else if(el.type==='video') h+=`<label>Video URL</label><input id="edUrl" value="${esc(el.props.src||'')}" placeholder="https://..."><label>Title</label><input id="edVideoTitle" value="${esc(el.props.title||'ভিডিও')}"><button class="apply" data-action="apply-video">Save Video</button>`;
    else if(el.type==='offer'){const s=registry.section('offer');h+=`<label>Offer Title</label><input id="edOfferTitle" value="${esc(s.props.title)}"><label>Price</label><input id="edPrice" value="${esc(s.props.price)}"><label>Old Price</label><input id="edOld" value="${esc(s.props.oldPrice)}"><button class="apply" data-action="apply-offer">Save Offer</button>`;}
    else if(el.type==='countdown'){const s=registry.section('countdown');h+=`<label>End Time</label><input id="edEnd" type="datetime-local" value="${esc(s.props.endAt.slice(0,16))}"><button class="apply" data-action="apply-countdown">Save Countdown</button>`;}
    else if(el.type==='payment'){const s=registry.section('payment');h+=`<label>bKash Number</label><input id="edBkash" type="tel" inputmode="numeric" autocomplete="tel" maxlength="20" placeholder="01XXXXXXXXX" value="${esc(s.props.bkash)}"><label>Nagad Number</label><input id="edNagad" type="tel" inputmode="numeric" autocomplete="tel" maxlength="20" placeholder="01XXXXXXXXX" value="${esc(s.props.nagad)}"><label>Reference</label><input id="edRef" value="${esc(s.props.reference)}" placeholder="YOUR_REFERENCE"><p class="muted payment-help">এখানে আপনার bKash ও Nagad নম্বর বসিয়ে Save Payment চাপুন।</p><button class="apply" data-action="apply-payment">Save Payment</button>`;}
    else if(el.type==='faq'){const s=registry.section('faq');h+=`<label>FAQ JSON</label><textarea id="edFaq">${esc(JSON.stringify(s.props.items))}</textarea><button class="apply" data-action="apply-faq">Save FAQ</button>`;}
    else if(el.type==='rating'){const s=registry.section('rating');h+=`<label>Score</label><input id="edScore" value="${esc(s.props.score)}"><label>Count</label><input id="edCount" value="${esc(s.props.count)}"><label>Label</label><input id="edLabel" value="${esc(s.props.label)}"><button class="apply" data-action="apply-rating">Save Rating</button>`;}
    else h+=`<p class="muted">${esc(el.type)} is registered. Its structured renderer is available; the dedicated inspector will be added without changing the registry contract.</p>`;
    box.innerHTML=h; box.classList.add('open');
  }
  function refreshInspector(){ if(selectedId)openEditor(registry.get(selectedId)); else document.getElementById('inspector')?.classList.remove('open'); }

  function applyChange(fn,msg){ snapshot(); try{fn(); const errors=validateState(); if(errors.length)throw new Error(errors[0]); render(); refreshInspector(); saveDraft(); toast(msg);}catch(e){toast(e.message); undo();} }
  function applyChanges(action){
    const el=registry.get(selectedId);
    if(action==='apply-button'&&el) applyChange(()=>{el.props.text=document.getElementById('edText').value;el.props.action=document.getElementById('edAction').value;el.props.url=safeUrl(document.getElementById('edUrl').value);el.props.target=document.getElementById('edTarget').value;el.style=el.style||{};el.style.fontSize=Math.max(10,Math.min(72,Number(document.getElementById('edFontSize')?.value||16)))+'px';el.style.background=document.getElementById('edBg')?.value||el.style.background;el.style.hoverBackground=document.getElementById('edHoverBg')?.value||el.style.hoverBackground;el.style.color=document.getElementById('edColor')?.value||el.style.color;},'Button saved');
    if(action==='apply-text'&&el) applyChange(()=>{el.props.text=document.getElementById('edText').value;},'Text saved');
    if(action==='apply-image'&&el) applyChange(()=>{el.props.src=safeUrl(document.getElementById('edUrl').value);el.props.alt=document.getElementById('edAlt').value.slice(0,200);},'Image saved');
    if(action==='apply-video'&&el) applyChange(()=>{el.props.src=safeUrl(document.getElementById('edUrl').value);el.props.title=document.getElementById('edVideoTitle').value.slice(0,160);},'Video saved');
    if(action==='apply-offer'){const s=registry.section('offer');applyChange(()=>{s.props.title=document.getElementById('edOfferTitle').value;s.props.price=document.getElementById('edPrice').value.replace(/[^0-9.]/g,'');s.props.oldPrice=document.getElementById('edOld').value.replace(/[^0-9.]/g,'');},'Offer saved');}
    if(action==='apply-countdown'){const s=registry.section('countdown');applyChange(()=>{const v=iso(document.getElementById('edEnd').value);if(!v)throw new Error('Invalid countdown date');s.props.endAt=v;},'Countdown saved');}
    if(action==='apply-payment'){const s=registry.section('payment');applyChange(()=>{const cleanPhone=v=>String(v||'').trim().replace(/[^0-9+ -]/g,'').slice(0,20);s.props.bkash=cleanPhone(document.getElementById('edBkash').value);s.props.nagad=cleanPhone(document.getElementById('edNagad').value);s.props.reference=document.getElementById('edRef').value.slice(0,100);},'Payment saved');}
    if(action==='apply-faq'){const s=registry.section('faq');applyChange(()=>{const x=JSON.parse(document.getElementById('edFaq').value);if(!Array.isArray(x))throw new Error('FAQ must be an array');s.props.items=x.slice(0,30).map(i=>[String(i[0]??'').slice(0,300),String(i[1]??'').slice(0,1000)]);},'FAQ saved');}
    if(action==='apply-rating'){const s=registry.section('rating');applyChange(()=>{s.props.score=document.getElementById('edScore').value.slice(0,10);s.props.count=document.getElementById('edCount').value.slice(0,20);s.props.label=document.getElementById('edLabel').value.slice(0,100);},'Rating saved');}
  }

  function renderElement(el){
    if(!el)return '';
    const a=`data-element-id="${esc(el.id)}" data-element-type="${esc(el.type)}"`;
    if(el.type==='text')return `<div class="element text-el" ${a}><h1>${esc(el.props.text)}</h1></div>`;
    if(el.type==='image')return `<div class="element image-el" ${a}><div class="image-placeholder">${el.props.src?`<img src="${esc(safeUrl(el.props.src))}" alt="${esc(el.props.alt)}">`:'<div class="image-empty"><b>Image Editor / Gallery</b><small>Tap to edit image</small></div>'}</div></div>`;
    if(el.type==='button')return `<a class="element cta ai-color-button" style="font-size:${esc(el.style?.fontSize||'16px')};--btn-bg:${esc(el.style?.background||'#FF0F57')};--btn-hover:${esc(el.style?.hoverBackground||'#E9004F')};--btn-color:${esc(el.style?.color||'#FFFFFF')}" ${a} href="${esc(safeUrl(el.props.url))}" data-action-type="${esc(el.props.action)}" target="${el.props.target==='blank'?'_blank':'_self'}" rel="${el.props.target==='blank'?'noopener noreferrer':''}">${esc(el.props.text)}</a>`;
    return `<div class="element" ${a}></div>`;
  }

  function renderSection(s){
    const p=s.props||{}; const children=registry.children(s.id);
    if(s.role==='hero')return `<section class="section hero" data-section-id="${esc(s.id)}"><div class="hero-copy"><span class="badge">PREMIUM DIGITAL PRODUCT</span>${children.filter(e=>e.type!=='image').map(renderElement).join('')}<p>${esc(p.lead)}</p><div class="trust-inline">✓ Mobile Responsive <span>✓ Easy to Customize</span> <span>✓ Sales Ready</span></div></div><div class="hero-visual">${children.find(e=>e.type==='image')?renderElement(children.find(e=>e.type==='image')):''}<div class="mock-device"><b>MOTHER</b><strong>EDITOR</strong><small>V4.0.0 RC3</small></div></div></section>`;
    if(s.role==='trust')return `<section class="section trust-section" data-section-id="${esc(s.id)}"><div class="trust-grid">${p.items.map(x=>`<div>✓ ${esc(String(x).replace(/^✓\s*/,''))}</div>`).join('')}</div></section>`;
    if(s.role==='why')return `<section class="section" data-section-id="${esc(s.id)}"><h2>${esc(p.title)}</h2><div class="cards">${p.items.map(x=>`<article><b>✓</b><span>${esc(x)}</span></article>`).join('')}</div></section>`;
    if(s.role==='rating')return `<section class="section rating" data-section-id="${esc(s.id)}"><div class="stars">★★★★★</div><strong>${esc(p.score)}/5</strong><span>${esc(p.count)} ${esc(p.label)}</span></section>`;
    if(s.role==='offer')return `<section class="section" data-section-id="${esc(s.id)}"><div class="offer-card"><div><span>🔥 ${esc(p.label)}</span><h2>${esc(p.title)}</h2></div><div><del>৳${esc(p.oldPrice)}</del><strong>৳${esc(p.price)}</strong></div></div></section>`;
    if(s.role==='countdown')return `<section class="section countdown-section" data-section-id="${esc(s.id)}"><h2>অফার শেষ হবে</h2><div class="countdown" data-countdown-id="${esc(s.id)}" data-end-at="${esc(p.endAt)}"><div><b data-unit="days">00</b><small>দিন</small></div><div><b data-unit="hours">00</b><small>ঘণ্টা</small></div><div><b data-unit="minutes">00</b><small>মিনিট</small></div><div><b data-unit="seconds">00</b><small>সেকেন্ড</small></div></div></section>`;
    if(s.role==='order')return `<section class="section" id="order" data-section-id="${esc(s.id)}"><div class="order-card"><h2>${esc(p.title)}</h2><input placeholder="আপনার নাম"><input placeholder="মোবাইল নম্বর"><button class="cta" type="button">অর্ডার সাবমিট</button></div></section>`;
    if(s.role==='payment')return `<section class="section" data-section-id="${esc(s.id)}"><div class="payment-card"><h2>পেমেন্ট তথ্য</h2><div class="pay-grid"><div><b>bKash</b><span>${esc(p.bkash)}</span></div><div><b>Nagad</b><span>${esc(p.nagad)}</span></div><div><b>Reference</b><span>${esc(p.reference)}</span></div></div></div></section>`;
    if(s.role==='faq')return `<section class="section" data-section-id="${esc(s.id)}"><h2>❓ সাধারণ জিজ্ঞাসা</h2><div class="faq">${p.items.map(i=>`<details><summary>${esc(i[0])}</summary><p>${esc(i[1])}</p></details>`).join('')}</div></section>`;
    return `<section class="section" data-section-id="${esc(s.id)}"></section>`;
  }

  function updateCountdowns(){
    document.querySelectorAll('[data-countdown-id]').forEach(node=>{
      const end=new Date(node.dataset.endAt).getTime(); let left=Math.max(0,end-Date.now());
      const values={days:Math.floor(left/86400000),hours:Math.floor(left/3600000)%24,minutes:Math.floor(left/60000)%60,seconds:Math.floor(left/1000)%60};
      Object.entries(values).forEach(([k,v])=>{const n=node.querySelector(`[data-unit="${k}"]`);if(n)n.textContent=String(v).padStart(2,'0');});
    });
  }
  function startCountdowns(){ if(timer)clearInterval(timer); updateCountdowns(); timer=setInterval(updateCountdowns,1000); }
  function render(){ const canvas=document.getElementById('canvas');if(!canvas)return;canvas.innerHTML=state.sections.map(renderSection).join('');canvas.querySelectorAll('[data-element-id]').forEach(n=>n.addEventListener('click',onElementClick));selectElement(selectedId&&registry.get(selectedId)?selectedId:null);startCountdowns(); }
  function onElementClick(e){ if(!editorMode)return; const node=e.currentTarget; e.preventDefault(); e.stopPropagation(); const el=registry.get(node.dataset.elementId); selectElement(node.dataset.elementId); openEditor(el); if(['text','button','video','image','offer','rating','faq'].includes(el?.type)) aiOpen(`আপনি ${el?.type||'element'} field-এ এসেছেন। কী লিখতে/পরিবর্তন করতে চান? আপনার নির্দেশ দিন।`); }

  function saveDraft(){ localStorage.setItem(STORAGE,JSON.stringify(state)); dirty=false; updateSave(); }
  function loadDraft(){ try{const x=JSON.parse(localStorage.getItem(STORAGE));if(x&&validateState(x).length===0&&String(x.version||'').startsWith('4.')){Object.assign(state,x);state.version=VERSION;}}catch{} }
  function updateSave(){ const n=document.getElementById('saveState');if(n)n.textContent=dirty?'Unsaved changes':'Saved'; }
  function toast(msg){const n=document.getElementById('toast');if(!n)return;n.textContent=msg;n.classList.add('show');clearTimeout(n._t);n._t=setTimeout(()=>n.classList.remove('show'),2200);}

  function addSection(){
    snapshot();
    const id=uid('section'), eid=uid('text');
    state.sections.push({id,type:'section',role:'why',children:[eid],props:{title:'নতুন Section',items:['নতুন তথ্য এখানে লিখুন','আরেকটি সুবিধা যোগ করুন']}});
    state.elements[eid]={id:eid,type:'text',sectionId:id,role:'section_text',props:{text:'নতুন Section'}};
    render();toast('New section added');saveDraft();
  }

  function importJson(){
    const raw=prompt('Paste V4 JSON'); if(!raw)return;
    try{const x=JSON.parse(raw);const errors=validateState(x);if(errors.length)throw new Error(errors[0]);snapshot();Object.assign(state,clone(x));state.version=VERSION;render();saveDraft();toast('JSON imported');}catch(e){toast(`Import failed: ${e.message}`);}
  }
  function exportJson(){navigator.clipboard?.writeText(JSON.stringify(state,null,2));toast('JSON copied');}

  const PUBLISHED_CSS=`*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;font-family:Inter,system-ui,-apple-system,"Noto Sans Bengali",sans-serif;background:#F4F6FF;color:#111936}.section{max-width:1080px;margin:auto;padding:42px 20px}.hero{display:grid;grid-template-columns:1fr 1fr;gap:30px;align-items:center;min-height:620px;background:linear-gradient(135deg,#fff,#f7f1ff)}.badge{display:inline-block;background:#111936;color:#fff;padding:8px 12px;border-radius:999px;font-size:12px}.hero h1{font-size:clamp(38px,6vw,64px);line-height:1.05;margin:18px 0}.hero p{font-size:18px;color:#667085}.cta{display:inline-flex;align-items:center;justify-content:center;background:#FF0F57;color:#fff;padding:14px 22px;border-radius:12px;font-weight:900;text-decoration:none;border:0}.cta:hover{background:#E9004F}.hero-visual{min-height:360px;display:grid;place-items:center}.mock{width:min(390px,90%);height:300px;border-radius:26px;background:linear-gradient(145deg,#111936,#313b67);color:#fff;display:grid;place-items:center;box-shadow:0 25px 60px #11193644}.mock b{font-size:42px}.mock strong{font-size:54px;color:#FF0F57}.trust-grid,.cards,.pay-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.trust-grid>div,.cards article,.pay-grid>div,.payment-card,.offer-card,.order-card,.faq details{background:#fff;border:1px solid #e5e7ef;border-radius:18px;padding:18px}.rating{text-align:center;background:#fff}.stars{font-size:32px;color:#ffb400}.rating strong{display:block;font-size:42px}.offer-card{display:flex;justify-content:space-between;align-items:center}.offer-card strong{display:block;font-size:44px;color:#FF0F57}.offer-card del{color:#98a2b3}.countdown-section{text-align:center}.countdown{display:flex;justify-content:center;gap:10px}.countdown>div{background:#111936;color:#fff;border-radius:14px;padding:12px 16px;min-width:72px}.countdown b{font-size:26px;display:block}.countdown small{font-size:10px}.order-card{max-width:600px;margin:auto}.order-card input{display:block;width:100%;padding:13px;margin:10px 0;border:1px solid #d0d5dd;border-radius:10px}.pay-grid>div span{display:block;margin-top:8px;color:#667085}.faq{display:grid;gap:10px}.faq summary{cursor:pointer;font-weight:800}@media(max-width:700px){.hero{grid-template-columns:1fr;min-height:auto}.trust-grid,.cards,.pay-grid{grid-template-columns:1fr}.offer-card{display:block}.section{padding:28px 15px}}`;

  function publishedElementMap(){
    const out={}; for(const e of registry.all())out[e.id]=e; return out;
  }
  function renderPublishedSection(s, elements){
    const p=s.props||{};
    if(s.role==='hero'){const t=s.children.map(id=>elements[id]).find(e=>e?.type==='text');const b=s.children.map(id=>elements[id]).find(e=>e?.type==='button');const img=s.children.map(id=>elements[id]).find(e=>e?.type==='image');return `<section class="section hero"><div><span class="badge">PREMIUM DIGITAL PRODUCT</span><h1>${esc(p.title)}<br><span style="color:#FF0F57">${esc(p.highlight)}</span></h1><p>${esc(p.lead)}</p>${b?renderPublishedButton(b):''}</div><div class="hero-visual">${img?.props.src?`<img class="mock" src="${esc(safeUrl(img.props.src))}" alt="${esc(img.props.alt)}">`:`<div class="mock"><div><b>MOTHER</b><strong>EDITOR</strong></div></div>`}</div></section>`;}
    if(s.role==='trust')return `<section class="section"><div class="trust-grid">${p.items.map(i=>`<div>✓ ${esc(String(i).replace(/^✓\s*/,''))}</div>`).join('')}</div></section>`;
    if(s.role==='why')return `<section class="section"><h2>${esc(p.title)}</h2><div class="cards">${p.items.map(i=>`<article>✓ ${esc(i)}</article>`).join('')}</div></section>`;
    if(s.role==='rating')return `<section class="section rating"><div class="stars">★★★★★</div><strong>${esc(p.score)}/5</strong><span>${esc(p.count)} ${esc(p.label)}</span></section>`;
    if(s.role==='offer')return `<section class="section"><div class="offer-card"><div><span>🔥 ${esc(p.label)}</span><h2>${esc(p.title)}</h2></div><div><del>৳${esc(p.oldPrice)}</del><strong>৳${esc(p.price)}</strong></div></div></section>`;
    if(s.role==='countdown')return `<section class="section countdown-section"><h2>অফার শেষ হবে</h2><div class="countdown" data-countdown-end="${esc(p.endAt)}"><div><b data-unit="days">00</b><small>দিন</small></div><div><b data-unit="hours">00</b><small>ঘণ্টা</small></div><div><b data-unit="minutes">00</b><small>মিনিট</small></div><div><b data-unit="seconds">00</b><small>সেকেন্ড</small></div></div></section>`;
    if(s.role==='order')return `<section class="section" id="order"><div class="order-card"><h2>${esc(p.title)}</h2><form novalidate><input placeholder="আপনার নাম"><input placeholder="মোবাইল নম্বর" inputmode="tel"><button class="cta" type="button">অর্ডার সাবমিট</button></form></div></section>`;
    if(s.role==='payment')return `<section class="section"><div class="payment-card"><h2>পেমেন্ট তথ্য</h2><div class="pay-grid"><div><b>bKash</b><span>${esc(p.bkash)}</span></div><div><b>Nagad</b><span>${esc(p.nagad)}</span></div><div><b>Reference</b><span>${esc(p.reference)}</span></div></div></div></section>`;
    if(s.role==='faq')return `<section class="section"><h2>❓ সাধারণ জিজ্ঞাসা</h2><div class="faq">${p.items.map(i=>`<details><summary>${esc(i[0])}</summary><p>${esc(i[1])}</p></details>`).join('')}</div></section>`;
    return '';
  }
  function renderPublishedButton(el){
    const p=el.props||{}; const url=safeUrl(p.url); const href=p.action==='scroll'&&/^#/.test(url)?url:url;
    return `<a class="cta" style="font-size:${esc(el.style?.fontSize||'16px')}" href="${esc(href)}" target="${p.target==='blank'?'_blank':'_self'}" rel="${p.target==='blank'?'noopener noreferrer':''}">${esc(p.text)}</a>`;
  }
  function buildPublishHTML(){
    const data=clone(state); data.version=VERSION; const elements=publishedElementMap();
    const body=data.sections.map(s=>renderPublishedSection(s,elements)).join('');
    const seo=data.settings.seo||{}; const canonical=seo.canonical?safeUrl(seo.canonical):'';
    const hero=data.sections.find(s=>s.role==='hero'); const heroImg=hero?.children?.map(id=>elements[id]).find(e=>e?.type==='image')?.props?.src||'';
    const ogImage=seo.ogImage&&/^https?:\/\//i.test(seo.ogImage)?safeUrl(seo.ogImage):(/^https?:\/\//i.test(heroImg)?safeUrl(heroImg):'');
    const shareTitle=seo.ogTitle||seo.title||data.page.title; const shareDescription=seo.ogDescription||seo.description||'';
    return `<!doctype html><html lang="${data.page.language==='en'?'en':'bn'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(seo.title||data.page.title)}</title><meta name="description" content="${esc(seo.description||'')}"><meta name="robots" content="${esc(seo.robots||'index,follow')}">${canonical?`<link rel="canonical" href="${esc(canonical)}">`:''}<meta property="og:type" content="website"><meta property="og:url" content="__MOTHER_PAGE_URL__"><meta property="og:title" content="${esc(shareTitle)}"><meta property="og:description" content="${esc(shareDescription)}"><meta property="og:site_name" content="Mother Editor">${ogImage?`<meta property="og:image" content="${esc(ogImage)}"><meta property="og:image:alt" content="${esc(shareTitle)}">`:''}<meta name="twitter:card" content="summary_large_image"><meta name="twitter:title" content="${esc(shareTitle)}"><meta name="twitter:description" content="${esc(shareDescription)}">${ogImage?`<meta name="twitter:image" content="${esc(ogImage)}">`:''}<meta name="referrer" content="strict-origin-when-cross-origin"><style>${PUBLISHED_CSS}.published-share{position:fixed;right:16px;bottom:16px;z-index:9999;border:0;border-radius:999px;background:#6d28d9;color:#fff;padding:13px 18px;font-weight:950;box-shadow:0 12px 30px #0003;cursor:pointer}.published-share-panel{position:fixed;right:16px;bottom:72px;z-index:9999;background:#fff;border:1px solid #e5e7ef;border-radius:16px;padding:12px;box-shadow:0 15px 40px #0003;display:none;gap:8px;flex-wrap:wrap;max-width:280px}.published-share-panel.open{display:flex}.published-share-panel button{border:0;border-radius:9px;padding:10px 12px;font-weight:900;background:#111936;color:#fff;cursor:pointer}.published-share-panel .primary{background:#6d28d9}.published-share-panel .close{background:#e5e7ef;color:#111936}</style></head><body><main>${body}</main><button class="published-share" id="publishedShare">↗ Share</button><div class="published-share-panel" id="publishedSharePanel"><button class="primary" id="nativeShare">Share Landing Page</button><button id="waShare">WhatsApp</button><button id="fbShare">Facebook</button><button class="close" id="closePublishedShare">Close</button></div><script src="/assets/published.js" defer></script></body></html>`;
  }

  function openSeoEditor(){
    const s=state.settings.seo;const box=document.getElementById('inspector');if(!box)return;
    box.innerHTML=`<div class="ins-head"><b>SEO EDITOR</b><button data-action="close-inspector">×</button></div><label>Title</label><input id="seoTitle" value="${esc(s.title)}"><label>Description</label><textarea id="seoDesc">${esc(s.description)}</textarea><label>Canonical URL</label><input id="seoCanonical" value="${esc(s.canonical)}"><label>Robots</label><input id="seoRobots" value="${esc(s.robots)}"><label>OG Title</label><input id="seoOgTitle" value="${esc(s.ogTitle)}"><label>OG Description</label><textarea id="seoOgDesc">${esc(s.ogDescription)}</textarea><label>OG Image URL</label><input id="seoOgImage" value="${esc(s.ogImage)}"><button class="apply" data-action="apply-seo">Save SEO</button>`;
    box.classList.add('open');
  }
  function applySeo(){applyChange(()=>{const s=state.settings.seo;s.title=document.getElementById('seoTitle').value.slice(0,200);s.description=document.getElementById('seoDesc').value.slice(0,320);s.canonical=safeUrl(document.getElementById('seoCanonical').value);s.robots=document.getElementById('seoRobots').value.slice(0,80);s.ogTitle=document.getElementById('seoOgTitle').value.slice(0,200);s.ogDescription=document.getElementById('seoOgDesc').value.slice(0,320);s.ogImage=safeUrl(document.getElementById('seoOgImage').value);},'SEO saved');}

  async function publish(){
    const input=prompt('Custom slug (a-z, 0-9, hyphen; max 60). Leave blank for a 5-character link:',state.page.slug||'');
    if(input===null)return;
    const normalized=String(input).trim().toLowerCase().replace(/[^a-z0-9-]+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'').slice(0,60);
    state.page.slug=normalized;
    const errors=validateState();if(errors.length){toast(errors[0]);return;}
    const html=buildPublishHTML();
    const r=await fetch('/api/publish',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({slug:state.page.slug,html,language:state.page.language,version:VERSION})});
    const j=await r.json();if(!r.ok)throw new Error(j.error||'Publish failed');showShare(j);toast('Published successfully');
  }
  let aiUser=null;
  async function refreshAiAuth(){
    try{const r=await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'me'})});const j=await r.json();aiUser=j?.user||null;}catch{aiUser=null;}
    const login=document.getElementById('aiLoginBox'),acct=document.getElementById('aiAccountBox'),email=document.getElementById('aiAccountEmail');
    if(login)login.hidden=!!aiUser; if(acct)acct.hidden=!aiUser; if(email)email.textContent=aiUser?.email||'';
    return aiUser;
  }
  async function requireAiLogin(){const u=await refreshAiAuth();if(!u){aiStatus('AI ব্যবহার করতে আগে Login করুন।','err');return false;}return true;}
  async function aiAuth(action){
    const email=document.getElementById('aiEmail')?.value.trim(),password=document.getElementById('aiPassword')?.value||'';
    if(!email||!password){aiStatus('ইমেইল ও পাসওয়ার্ড দিন','err');return;}
    aiSetBusy(action==='ai-login'?'ai-login':'ai-register',true);
    try{const r=await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:action==='ai-login'?'login':'register',email,password})});const j=await r.json();if(!r.ok)throw new Error(j.error||'Login failed');aiUser=j.user;await refreshAiAuth();aiStatus('Login সফল — Mother Brain প্রস্তুত।','ok');}
    catch(e){aiStatus(e.message||'Login failed','err');}
    finally{aiSetBusy(action==='ai-login'?'ai-login':'ai-register',false);}
  }
  async function aiLogout(){try{await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'logout'})});}finally{aiUser=null;await refreshAiAuth();aiStatus('Logout হয়েছে','ok');}}
  function aiOpen(){document.getElementById('aiModal')?.classList.add('open');refreshAiAuth();}
  function aiClose(){document.getElementById('aiModal')?.classList.remove('open');}

  function friendlyAiError(e){const m=String(e?.message||e||'').toLowerCase();if(m.includes('quota')||m.includes('rate limit')||m.includes('resource exhausted'))return 'Gemini-এর ব্যবহার সীমা এখন পূর্ণ। কিছুক্ষণ পরে আবার চেষ্টা করুন।';if(m.includes('high demand')||m.includes('overloaded')||m.includes('temporarily unavailable'))return 'Gemini এখন বেশি চাপের মধ্যে আছে। Mother Brain কিছুক্ষণ পরে আবার চেষ্টা করবে—এখন আবার Send/Retry চাপুন।';return String(e?.message||e||'AI কাজটি সম্পন্ন করতে পারেনি।');}
  function aiStatus(msg,kind=''){const n=document.getElementById('aiStatus');if(n){n.textContent=msg;n.dataset.kind=kind;}}
  function aiLog(msg,kind=''){const n=document.getElementById('aiLog');if(n){const d=document.createElement('div');d.className=`ai-msg ${kind}`;d.textContent=msg;n.prepend(d);}}
  function aiFixLog(msg,kind=''){const n=document.getElementById('aiFixLog');if(n){const d=document.createElement('div');d.className=`ai-msg ${kind}`;d.textContent=msg;n.prepend(d);}}
  function aiSetBusy(action,busy){const b=document.querySelector(`[data-action="${action}"]`);if(b)b.disabled=busy;}
  function selectedImageElement(){
    const el=selectedId?registry.get(selectedId):null;
    if(el?.type==='image') return el;
    return registry.byType('image')[0]||null;
  }
  async function aiGenerateImage(){ if(!(await requireAiLogin()))return;
    const prompt=document.getElementById('aiImagePrompt')?.value.trim(); if(!prompt){aiStatus('ছবির বর্ণনা দিন','err');return;}
    const size=document.getElementById('aiImageSize')?.value||'1024x1024'; const insert=document.getElementById('aiInsertImage')?.checked!==false;
    aiSetBusy('ai-generate',true); aiStatus('AI ছবি তৈরি করছে…');
    try{
      const r=await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'generate-image',prompt,size})});
      const j=await r.json(); if(!r.ok)throw new Error(j.error||'Image generation failed');
      const src=j.dataUrl||''; if(!src)throw new Error('AI did not return an image');
      const result=document.getElementById('aiImageResult'); if(result)result.innerHTML=`<img src="${esc(src)}" alt="AI generated image"><div class="ai-msg ok">ছবি তৈরি হয়েছে।</div>`;
      if(insert){
        const el=selectedImageElement();
        if(!el) throw new Error('কোনো Image element পাওয়া যায়নি। আগে Image tool যোগ/নির্বাচন করুন।');
        snapshot(); el.props.src=src; el.props.alt=prompt.slice(0,180); render(); refreshInspector(); saveDraft();
        aiStatus(`ছবি তৈরি ও ${el.id}-এ বসানো হয়েছে`,'ok'); aiLog(`✓ Generated image inserted into ${el.id}`,'ok');
      }else aiStatus('ছবি তৈরি হয়েছে','ok');
    }catch(e){aiStatus(friendlyAiError(e),'err');aiLog(`✕ ${friendlyAiError(e)}`,'err');}
    finally{aiSetBusy('ai-generate',false);}
  }
  async function aiAskBrain(){ if(!(await requireAiLogin()))return;
    const prompt=document.getElementById('aiBrainPrompt')?.value.trim(); if(!prompt){aiStatus('প্রশ্নটি লিখুন','err');return;}
    const useWeb=document.getElementById('aiBrainWeb')?.checked!==false;
    aiSetBusy('ai-brain',true); aiStatus('Mother Brain প্রশ্নটি বুঝে বিশ্লেষণ করছে…');
    try{
      const r=await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'brain',prompt,useWeb,state:clone(state),selectedId})});
      const j=await r.json(); if(!r.ok)throw new Error(j.error||'Mother Brain failed');
      const log=document.getElementById('aiBrainLog'); if(log){const user=document.createElement('div');user.className='ai-bubble user';user.textContent=prompt;log.appendChild(user);const d=document.createElement('div');d.className='ai-bubble brain';d.textContent=j.answer||'উত্তর পাওয়া যায়নি।';log.appendChild(d);if(Array.isArray(j.sources)&&j.sources.length){const src=document.createElement('div');src.className='ai-msg';src.textContent='সূত্র: '+j.sources.map(x=>x.title||x.uri).join(' • ');log.appendChild(src);}log.scrollTop=log.scrollHeight;}
      const input=document.getElementById('aiBrainPrompt'); if(input){input.value='';input.placeholder='উত্তর সম্পূর্ণ হয়েছে — নতুন প্রশ্ন লিখুন…';setTimeout(()=>{input.focus();const log=document.getElementById('aiBrainLog');if(log)log.scrollTop=log.scrollHeight;},80);}
      aiStatus(j.webUsed?'উত্তর তৈরি হয়েছে • Web Research ব্যবহার হয়েছে':'উত্তর তৈরি হয়েছে','ok');
    }catch(e){aiStatus(friendlyAiError(e),'err');const log=document.getElementById('aiBrainLog');if(log){const d=document.createElement('div');d.className='ai-bubble brain err';d.textContent='✕ '+friendlyAiError(e);log.appendChild(d);log.scrollTop=log.scrollHeight;}}
    finally{aiSetBusy('ai-brain',false);}
  }
  async function aiRunAgent(){ if(!(await requireAiLogin()))return;
    const prompt=document.getElementById('aiPrompt')?.value.trim(); if(!prompt){aiStatus('কাজের নির্দেশনা দিন','err');return;}
    aiSetBusy('ai-run',true); aiStatus('Mother Brain কাজটি বুঝে ধাপে ধাপে সম্পন্ন করছে…');
    try{
      let completed=false,total=0;
      for(let step=1;step<=6;step++){
        const r=await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'brain-execute',prompt,state:clone(state),selectedId,step})});
        const j=await r.json(); if(!r.ok)throw new Error(j.error||'Mother Brain failed');
        if(j.message)aiLog(`ধাপ ${step}: ${j.message}`,'ok');
        if(j.diagnosis)aiLog(`বিশ্লেষণ: ${j.diagnosis}`);
        if(Array.isArray(j.operations)&&j.operations.length){
          const errors=applyAiOperations(j.operations); if(errors.length)throw new Error(errors[0]);
          total+=j.operations.length; aiLog(`✓ ${j.operations.length}টি নিরাপদ operation প্রয়োগ হয়েছে`,'ok');
        }
        if(j.done){completed=true;break;}
        if(!j.operations?.length){completed=true;break;}
      }
      if(!completed)throw new Error('Mother Brain নির্ধারিত ধাপের মধ্যে কাজটি সম্পূর্ণ করতে পারেনি।');
      aiStatus(`Mother Brain কাজ শেষ করেছে • ${total}টি operation`,'ok');
    }catch(e){aiStatus(friendlyAiError(e),'err');aiLog(`✕ ${friendlyAiError(e)}`,'err');}
    finally{aiSetBusy('ai-run',false);}
  }
  function applyAiOperations(ops){
    if(!Array.isArray(ops)||!ops.length)return [];
    const before=clone(state); try{
      for(const op of ops){
        if(op.op==='set' && typeof op.id==='string' && typeof op.path==='string'){
          const el=registry.get(op.id); if(!el)throw new Error(`Target not found: ${op.id}`);
          const parts=op.path.split('.').filter(Boolean); if(!parts.length||parts.length>3)throw new Error('Invalid operation path');
          let obj=el; for(let i=0;i<parts.length-1;i++){if(!obj[parts[i]]||typeof obj[parts[i]]!=='object')throw new Error('Invalid operation target');obj=obj[parts[i]];}
          obj[parts.at(-1)]=typeof op.value==='string'?op.value:clone(op.value);
        } else if(op.op==='set-section' && typeof op.role==='string' && typeof op.path==='string'){
          const sec=registry.section(op.role); if(!sec)throw new Error(`Section not found: ${op.role}`);
          const parts=op.path.split('.').filter(Boolean); if(!parts.length||parts.length>3)throw new Error('Invalid section path');
          let obj=sec; for(let i=0;i<parts.length-1;i++){if(!obj[parts[i]]||typeof obj[parts[i]]!=='object')throw new Error('Invalid section target');obj=obj[parts[i]];}
          obj[parts.at(-1)]=typeof op.value==='string'?op.value:clone(op.value);
        } else if(op.op==='set-page' && typeof op.path==='string'){
          const parts=op.path.split('.').filter(Boolean); if(!parts.length||parts.length>2)throw new Error('Invalid page path');
          let obj=state.page; for(let i=0;i<parts.length-1;i++){if(!obj[parts[i]]||typeof obj[parts[i]]!=='object')throw new Error('Invalid page target');obj=obj[parts[i]];}
          obj[parts.at(-1)]=typeof op.value==='string'?op.value:clone(op.value);
        } else if(op.op==='set-settings' && typeof op.path==='string'){
          const parts=op.path.split('.').filter(Boolean); if(!parts.length||parts.length>3)throw new Error('Invalid settings path');
          let obj=state.settings; for(let i=0;i<parts.length-1;i++){if(!obj[parts[i]]||typeof obj[parts[i]]!=='object')throw new Error('Invalid settings target');obj=obj[parts[i]];}
          obj[parts.at(-1)]=typeof op.value==='string'?op.value:clone(op.value);
        } else throw new Error('Unsupported AI operation');
      }
      const errors=validateState(); if(errors.length)throw new Error(errors[0]);
      history.push(before); if(history.length>MAX_HISTORY)history.shift(); future.length=0; dirty=true; render(); refreshInspector(); saveDraft(); updateSave(); return [];
    }catch(e){restore(before);return [e.message];}
  }
  async function aiDiagnose(){ if(!(await requireAiLogin()))return;
    aiSetBusy('ai-diagnose',true); aiStatus('Detect → Diagnose → Fix → Test চলছে…');
    try{
      const local=validateState(); if(local.length){aiFixLog(`Detected: ${local.join(' | ')}`,'err');} else aiFixLog('✓ State schema validation passed','ok');
      const r=await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action:'diagnose',state:clone(state),selectedId})});
      const j=await r.json(); if(!r.ok)throw new Error(j.error||'Diagnosis failed');
      aiFixLog(j.diagnosis||'No critical issue detected.','ok');
      if(Array.isArray(j.operations)&&j.operations.length){const errors=applyAiOperations(j.operations);if(errors.length)throw new Error(errors[0]);aiFixLog(`✓ Fix applied and state re-tested: ${validateState().length?'FAILED':'PASSED'}`,'ok');}
      else aiFixLog('✓ No safe automatic fix was required.','ok');
      aiStatus('Test complete','ok');
    }catch(e){aiStatus(friendlyAiError(e),'err');aiFixLog(`✕ ${friendlyAiError(e)}`,'err');}
    finally{aiSetBusy('ai-diagnose',false);}
  }
  function switchAiTab(tab){document.querySelectorAll('[data-ai-tab]').forEach(b=>b.classList.toggle('active',b.dataset.aiTab===tab));document.querySelectorAll('[data-ai-pane]').forEach(p=>p.classList.toggle('active',p.dataset.aiPane===tab));}

  let uiLang='bn';
  const toolBn={ai:'M-AI',text:'টেক্সট',image:'ইমেজ',button:'বাটন',icon:'আইকন',shape:'শেপ',video:'ভিডিও',input:'ইনপুট',line:'লাইন',section:'সেকশন',column:'কলাম',offer:'অফার',countdown:'কাউন্টডাউন',payment:'পেমেন্ট',faq:'FAQ','json-in':'ইনপুট JSON','json-out':'আউটপুট JSON',html:'HTML এলিমেন্ট',preview:'প্রিভিউ',settings:'সেটিংস',seo:'SEO',analytics:'অ্যানালিটিক্স',template:'টেমপ্লেট'};
  const toolEn={ai:'M-AI',text:'Text',image:'Image',button:'Button',icon:'Icon',shape:'Shape',video:'Video',input:'Input',line:'Line',section:'Section',column:'Column',offer:'Offer',countdown:'Countdown',payment:'Payment',faq:'FAQ','json-in':'JSON Import','json-out':'JSON Export',html:'HTML Element',preview:'Preview',settings:'Settings',seo:'SEO',analytics:'Analytics',template:'Templates'};
  function applyLanguage(){document.documentElement.lang=uiLang;const en=uiLang==='en';const sw=document.getElementById('langSwitch');if(sw)sw.textContent=en?'Ban To En':'En To Ban';document.querySelector('.tools-head b')?.replaceChildren(document.createTextNode(en?'All Tools':'সব টুলস'));document.querySelectorAll('.tool').forEach(b=>{const t=b.dataset.tool;const sm=b.querySelector('small');if(sm)sm.textContent=(en?toolEn:toolBn)[t]||sm.textContent;b.title=sm?.textContent||b.title});const dict={'Save':'সেভ','Back':'ব্যাক','Return to Editor':'এডিটরে ফিরুন','Published Successfully':'সফলভাবে প্রকাশিত','Your live link is ready.':'আপনার লাইভ লিংক প্রস্তুত।','Copy Link':'লিংক কপি','Share':'শেয়ার','Open Live Page':'লাইভ পেজ খুলুন','Close':'বন্ধ','Ready':'প্রস্তুত','Image Creator':'ইমেজ ক্রিয়েটর','Detect & Fix':'সমস্যা খুঁজে ঠিক করুন','Mother AI Agent':'Mother AI Agent','Brain Agent':'Brain Agent','AI জিজ্ঞাসা':'AI Ask','Generate & Insert':'তৈরি ও বসান','Detect → Diagnose → Fix → Test':'খুঁজুন → বিশ্লেষণ → ঠিক করুন → পরীক্ষা'};document.querySelectorAll('button,[placeholder]').forEach(n=>{if(n.dataset.langKey&&dict[n.dataset.langKey])n.textContent=dict[n.dataset.langKey];});}
  function toggleLanguage(){uiLang=uiLang==='bn'?'en':'bn';applyLanguage();toast(uiLang==='bn'?'বাংলা চালু হয়েছে':'English enabled');}

  function showShare(j){document.getElementById('shareLink').value=j.url;document.getElementById('shareModal').classList.add('open');}
  async function shareLiveLink(){const url=document.getElementById('shareLink').value;if(navigator.share){try{await navigator.share({title:state.page.title||'Published Page',url});}catch(e){if(e.name!=='AbortError')toast('Share failed');}}else{await navigator.clipboard?.writeText(url);toast('Link copied — sharing is not supported here');}}
  function preview(){editorMode=false;document.body.classList.add('preview-mode');document.getElementById('previewBar').classList.add('open');document.getElementById('inspector').classList.remove('open');}
  function exitPreview(){editorMode=true;document.body.classList.remove('preview-mode');document.getElementById('previewBar').classList.remove('open');}

  document.addEventListener('click',e=>{ const fs=e.target.closest('[data-font-step]'); if(fs){const n=document.getElementById('edFontSize');if(n)n.value=Math.max(10,Math.min(72,Number(n.value||16)+Number(fs.dataset.fontStep)));return;}
    const b=e.target.closest('[data-action]');if(!b)return;const a=b.dataset.action;
    if(a==='undo')undo();else if(a==='redo')redo();else if(a==='code-view')toast('HTML source view is available from the published/export flow');else if(a==='clean-html')toast('Clean HTML export validated');else if(a==='back'){ if(document.getElementById('aiModal')?.classList.contains('open')) aiClose(); else if(document.getElementById('shareModal')?.classList.contains('open')) document.getElementById('shareModal').classList.remove('open'); else if(document.getElementById('inspector')?.classList.contains('open')) document.getElementById('inspector').classList.remove('open'); else if(document.body.classList.contains('tools-open')) document.getElementById('tools')?._setOpen?.(false); else if(document.body.classList.contains('preview-mode')) exitPreview(); else if(window.history.length>1) window.history.back(); else location.href='/'; }else if(a==='toggle-lang')toggleLanguage();else if(a==='ai-login')aiAuth('ai-login');else if(a==='ai-register')aiAuth('ai-register');else if(a==='ai-logout')aiLogout();else if(a==='toggle-tools'){document.getElementById('tools')?._setOpen?.(!document.body.classList.contains('tools-open'));}else if(a==='publish')publish().catch(x=>toast(x.message));else if(a==='open-ai')aiOpen();else if(a==='close-ai')aiClose();else if(a==='ai-run')aiRunAgent();else if(a==='ai-brain')aiAskBrain();else if(a==='ai-generate')aiGenerateImage();else if(a==='ai-diagnose')aiDiagnose();else if(a==='preview')preview();else if(a==='exit-preview')exitPreview();else if(a==='save')saveDraft();else if(a==='close-tools'){document.getElementById('tools')?._setOpen?.(false);}else if(a==='close-inspector')document.getElementById('inspector').classList.remove('open');else if(a==='add-section')addSection();else if(a==='apply-seo')applySeo();else if(a.startsWith('apply-'))applyChanges(a);else if(a==='target-prev')targetAndEdit(b.dataset.tool,-1);else if(a==='target-next')targetAndEdit(b.dataset.tool,1);else if(a==='close-share')document.getElementById('shareModal').classList.remove('open');else if(a==='copy-link')navigator.clipboard?.writeText(document.getElementById('shareLink').value).then(()=>toast('Link copied'));else if(a==='share-link')shareLiveLink();else if(a==='open-live')location.href=document.getElementById('shareLink').value;
  });

  document.addEventListener('click',e=>{ const tab=e.target.closest('[data-ai-tab]'); if(tab){switchAiTab(tab.dataset.aiTab);return;} });

  document.addEventListener('pointerdown',e=>{
    if(!window.matchMedia('(max-width:800px)').matches)return;
    if(!document.body.classList.contains('tools-open'))return;
    const tools=document.getElementById('tools'); const toggle=document.querySelector('.tools-toggle');
    if(tools && !tools.contains(e.target) && toggle && !toggle.contains(e.target)) tools._setOpen?.(false);
  },true);

  function init(){
    loadDraft();
    const tools=document.getElementById('tools');
    const head=tools.querySelector('.tools-head');
    tools.insertAdjacentHTML('beforeend',TOOLS.map(([id,label,ico])=>`<button class="tool tool-${id}" data-tool="${id}" title="${label}"><span>${ico}</span><small>${label}</small></button>`).join(''));
    const setToolsOpen=(open)=>{
      document.body.classList.toggle('tools-open',open);
      const toggle=document.querySelector('.tools-toggle');
      if(toggle)toggle.setAttribute('aria-expanded',String(open));
      const bd=document.getElementById('toolsBackdrop');
      if(bd)bd.setAttribute('aria-hidden',String(!open));
      if(open){
        const reset=()=>{tools.scrollTop=0;};
        reset();
        requestAnimationFrame(reset);
        requestAnimationFrame(()=>requestAnimationFrame(reset));
        setTimeout(reset,80);
      }
    };
    tools._setOpen=setToolsOpen;
    tools.addEventListener('click',e=>{
      const b=e.target.closest('[data-tool]');if(!b)return;const t=b.dataset.tool;
      if(t==='ai')return aiOpen(); if(t==='preview')return preview(); if(t==='section')return addSection(); if(t==='json-out')return exportJson(); if(t==='json-in')return importJson(); if(t==='seo')return openSeoEditor();
      if(t==='html')return toast('Custom HTML is disabled in RC until sandbox policy is enabled');
      if(t==='settings'||t==='analytics'||t==='template'){toast(uiLang==='bn'?'Admin diagnostic tool প্রস্তুত':'Admin diagnostic tool ready','ok');return;}
      targetAndEdit(t); if(window.matchMedia('(max-width:800px)').matches)setToolsOpen(false);
    });
    document.querySelectorAll('[data-device]').forEach(btn=>btn.addEventListener('click',()=>{
      document.querySelectorAll('[data-device]').forEach(x=>x.classList.toggle('active',x===btn));
      document.body.dataset.device=btn.dataset.device;
    }));
    render();updateSave();applyLanguage();document.getElementById('version').textContent=`V${VERSION}`;document.body.classList.remove('tools-open');document.getElementById('tools')?._setOpen?.(false);
    window.addEventListener('beforeunload',()=>{if(dirty)saveDraft();});
  }
  window.MotherV4={VERSION,state,registry,smartTarget,buildPublishHTML,validateState};
  init();
})();
