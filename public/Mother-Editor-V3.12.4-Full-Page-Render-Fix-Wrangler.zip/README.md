# Mother Editor V3.12.4

Full-page render correction build.

Fixes included:
- Restores/render-locks all screenshot sales-page sections from Hero through FAQ.
- Mobile canvas width/overflow hardening.
- Header remains stable.
- Smart target, return, no-blur, image gallery, element and countdown fixes from prior V3.12 builds are retained.
- Version badge updated to V3.12.4.

Deployment: use Wrangler/Git for the Pages project with `_worker.js` in the deployment directory.
Example: `npx wrangler pages deploy . --project-name=mother-editor`

V3.10 Live Master is not modified.
