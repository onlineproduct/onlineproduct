/**
 * Mother Editor V3.10 - Cloudflare Pages Advanced Mode worker
 * - Serves the static editor through env.ASSETS
 * - POST /api/publish creates a NEW unique live page every time
 * - GET  /p/:slug serves the stored published HTML
 * - OPTIONS /api/* supports same-origin/CORS-friendly requests
 * Requires a Workers KV binding named PAGES.
 */

const JSON_HEADERS = {
  "content-type": "application/json; charset=UTF-8",
  "cache-control": "no-store",
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });
}

function cleanBaseSlug(value) {
  const s = String(value || "my-digital-product")
    .trim().toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
  return s || "my-digital-product";
}

function makeUniqueSlug() {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  const bytes = new Uint8Array(5);
  crypto.getRandomValues(bytes);
  let out = "";
  for (const b of bytes) out += chars[b % chars.length];
  return out;
}

function pageKey(slug) {
  return `page:${slug}`;
}

function isValidSlug(slug) {
  // Support new 5-character auto links, custom slugs, and legacy V3 links.
  return /^[a-z0-9]{5}$/.test(slug) || /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(slug);
}

async function handlePublish(request, env, origin) {
  if (request.method !== "POST") return json({ ok: false, error: "Method not allowed" }, 405);
  if (!env.PAGES) return json({ ok: false, error: "KV binding PAGES is not configured" }, 500);

  let body;
  try { body = await request.json(); }
  catch { return json({ ok: false, error: "Invalid JSON" }, 400); }

  const html = typeof body?.html === "string" ? body.html : "";
  if (!html.trim()) return json({ ok: false, error: "HTML is required" }, 400);
  if (html.length > 24 * 1024 * 1024) return json({ ok: false, error: "HTML is too large" }, 413);

  const customSlug = typeof body?.customSlug === "string" ? body.customSlug.trim() : "";
  let slug;
  let key;

  if (customSlug) {
    if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(customSlug) || customSlug.length > 60) {
      return json({ ok: false, error: "Invalid custom link. Use lowercase a-z, 0-9 and hyphen only (max 60 chars)." }, 400);
    }
    slug = customSlug;
    key = pageKey(slug);
    if (await env.PAGES.get(key)) {
      return json({ ok: false, error: "This custom link is already in use. Please choose another link." }, 409);
    }
  } else {
    // No custom link: generate a new 5-character short URL on every Publish.
    slug = makeUniqueSlug();
    key = pageKey(slug);
    for (let i = 0; i < 3 && await env.PAGES.get(key); i++) {
      slug = makeUniqueSlug();
      key = pageKey(slug);
    }
    if (await env.PAGES.get(key)) return json({ ok: false, error: "Could not allocate a unique link; try again" }, 503);
  }

  const record = {
    html,
    slug,
    createdAt: new Date().toISOString(),
  };

  await env.PAGES.put(key, JSON.stringify(record));

  const url = `${origin}/p/${encodeURIComponent(slug)}`;
  return json({ ok: true, slug, url, createdAt: record.createdAt }, 201);
}

async function handleLivePage(request, env, slug) {
  if (!env.PAGES) return new Response("KV binding PAGES is not configured", { status: 500 });
  if (!isValidSlug(slug)) return new Response("Not found", { status: 404 });

  const raw = await env.PAGES.get(pageKey(slug));
  if (!raw) return new Response("Live page not found", { status: 404 });

  let record;
  try { record = JSON.parse(raw); } catch { return new Response("Stored page is invalid", { status: 500 }); }

  return new Response(record.html, {
    status: 200,
    headers: {
      "content-type": "text/html; charset=UTF-8",
      "cache-control": "public, max-age=60, s-maxage=60",
      "x-mother-editor-live": "v3.10",
    },
  });
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "OPTIONS" && url.pathname.startsWith("/api/")) {
      return new Response(null, {
        status: 204,
        headers: {
          "access-control-allow-origin": url.origin,
          "access-control-allow-methods": "POST, OPTIONS",
          "access-control-allow-headers": "content-type",
          "access-control-max-age": "86400",
        },
      });
    }

    if (url.pathname === "/api/health") {
      return json({ ok: true, service: "mother-editor-publish", version: "3.10" });
    }

    if (url.pathname === "/api/publish") {
      const response = await handlePublish(request, env, url.origin);
      response.headers.set("access-control-allow-origin", url.origin);
      return response;
    }

    if (url.pathname.startsWith("/p/")) {
      const slug = decodeURIComponent(url.pathname.slice(3)).split("/")[0];
      return handleLivePage(request, env, slug);
    }

    return env.ASSETS.fetch(request);
  },
};
